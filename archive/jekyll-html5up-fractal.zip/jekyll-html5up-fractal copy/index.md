---
layout: default
title: Home
---

<!-- One -->
<section id="one" class="wrapper style2 special">
	<header class="major">
		<h2>Sed ipsum magna lorem tempus amet<br />
		vehicula et gravida elementum</h2>
	</header>
	<ul class="icons major">
		<li><span class="icon fa-camera-retro"><span class="label">Shoot</span></span></li>
		<li><span class="icon fa-refresh"><span class="label">Process</span></span></li>
		<li><span class="icon fa-cloud"><span class="label">Upload</span></span></li>
	</ul>
</section>

<!-- Two -->
<section id="two" class="wrapper">
	<div class="inner alt">
		<section class="spotlight">
			<div class="image"><img src="assets/images/pic01.jpg" alt="" /></div>
			<div class="content">
				<h3>Magna sed ultrices</h3>
				<p>Morbi mattis ornare ornare. Duis quam turpis, gravida at leo elementum elit fusce accumsan dui libero, quis vehicula lectus ultricies eu. In convallis amet leo non sapien iaculis efficitur consequat lorem ipsum.</p>
			</div>
		</section>
		<section class="spotlight">
			<div class="image"><img src="assets/images/pic02.jpg" alt="" /></div>
			<div class="content">
				<h3>Ultrices nullam aliquam</h3>
				<p>Morbi mattis ornare ornare. Duis quam turpis, gravida at leo elementum elit fusce accumsan dui libero, quis vehicula lectus ultricies eu. In convallis amet leo non sapien iaculis efficitur consequat lorem ipsum.</p>
			</div>
		</section>
		<section class="spotlight">
			<div class="image"><img src="assets/images/pic03.jpg" alt="" /></div>
			<div class="content">
				<h3>Aliquam sed magna</h3>
				<p>Morbi mattis ornare ornare. Duis quam turpis, gravida at leo elementum elit fusce accumsan dui libero, quis vehicula lectus ultricies eu. In convallis amet leo non sapien iaculis efficitur consequat lorem ipsum.</p>
			</div>
		</section>
		<section class="special">
			<ul class="icons labeled">
				<li><span class="icon fa-camera-retro"><span class="label">Ipsum lorem accumsan</span></span></li>
				<li><span class="icon fa-refresh"><span class="label">Sed vehicula elementum</span></span></li>
				<li><span class="icon fa-cloud"><span class="label">Elit fusce consequat</span></span></li>
				<li><span class="icon fa-code"><span class="label">Lorem nullam tempus</span></span></li>
				<li><span class="icon fa-desktop"><span class="label">Adipiscing amet sapien</span></span></li>
			</ul>
		</section>
	</div>
</section>
